This project is for the lab assessment of Web Technologies unit in WSU

Technologies has been used for this project are:

1. HTML
2. CSS Zen Garden
3. Javascript
4. PHP
5. MySQL
6. WSU internal student server for hosting purpose.
